var WastelandNPCs = {
    survivors: [],
    snakes: [],
    coyotes: [],
    spiders: [],
    helis: [],
    bosses: [],
    hydras: [],
    shopkeepers: [],

    init: function (scene) {
        // Any global init for NPCs
    },

    // --- FAUNA (Snakes/Coyotes) ---
    snakeMat: null,
    patternMat: null,
    eyeMat: null,
    furMat: null,

    spawnSnake: function (scene, core, customX, customZ) {
        if (!this.snakeMat) {
            this.snakeMat = new BABYLON.StandardMaterial("snakeMat", scene);
            this.snakeMat.diffuseColor = new BABYLON.Color3(0.5, 0.4, 0.2);
            this.patternMat = new BABYLON.StandardMaterial("patternMat", scene);
            this.patternMat.diffuseColor = new BABYLON.Color3(0.3, 0.2, 0.1);
            this.eyeMat = new BABYLON.StandardMaterial("eyeMat", scene);
            this.eyeMat.diffuseColor = BABYLON.Color3.Black();
        }

        var x = (customX !== undefined) ? customX : (Math.random() * 1000) - 500;
        var z = (customZ !== undefined) ? customZ : (Math.random() * 1000) - 500;

        var segments = [];
        for (var j = 0; j < 12; j++) {
            var diameter = 1.0;
            if (j === 1) diameter = 0.65;
            else if (j > 8) diameter = 1.0 - ((j - 8) * 0.2);
            else diameter = 1.0 - (j * 0.02);

            var s = BABYLON.MeshBuilder.CreateSphere("snake_seg", { diameter: diameter, segments: 8 }, scene);
            s.material = (j % 2 === 0) ? this.snakeMat : this.patternMat;

            if (j === 0) {
                s.scaling.z = 1.4;
                var eyeL = BABYLON.MeshBuilder.CreateSphere("eyeL", { diameter: 0.15 }, scene);
                eyeL.material = this.eyeMat;
                eyeL.position = new BABYLON.Vector3(-0.25 * diameter, 0.2 * diameter, 0.3 * diameter);
                eyeL.parent = s;
                var eyeR = eyeL.clone();
                eyeR.position.x = 0.25 * diameter;
                eyeR.parent = s;
            }

            s.position = new BABYLON.Vector3(x, 0, z + (j * 0.4));
            segments.push(s);
        }

        this.snakes.push({
            segments: segments,
            dir: new BABYLON.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize(),
            speed: 3.0 + Math.random(),
            turnTimer: 0,
            hp: 25,
            isFeral: false,
            visualTimer: 0
        });
    },

    createSnakes: function (scene, count, core) {
        for (var i = 0; i < count; i++) {
            this.spawnSnake(scene, core);
        }
    },

    spawnCoyote: function (scene, core, customX, customZ) {
        if (!this.furMat) {
            this.furMat = new BABYLON.StandardMaterial("furMat", scene);
            this.furMat.diffuseColor = new BABYLON.Color3(0.5, 0.4, 0.3);
        }

        var x = (customX !== undefined) ? customX : (Math.random() * 1000) - 500;
        var z = (customZ !== undefined) ? customZ : (Math.random() * 1000) - 500;

        var root = new BABYLON.TransformNode("coyote", scene);
        root.position = new BABYLON.Vector3(x, 0, z);

        var body = BABYLON.MeshBuilder.CreateBox("body", { width: 0.5, height: 0.6, depth: 1.2 }, scene);
        body.parent = root; body.position.y = 0.6; body.material = this.furMat;

        var head = BABYLON.MeshBuilder.CreateBox("head", { width: 0.4, height: 0.4, depth: 0.5 }, scene);
        head.parent = body; head.position = new BABYLON.Vector3(0, 0.4, 0.6); head.material = this.furMat;

        var snout = BABYLON.MeshBuilder.CreateBox("snout", { width: 0.2, height: 0.2, depth: 0.3 }, scene);
        snout.parent = head; snout.position.z = 0.3; snout.material = this.furMat;

        var earL = BABYLON.MeshBuilder.CreatePolyhedron("earL", { type: 1, size: 0.1 }, scene);
        earL.parent = head; earL.position = new BABYLON.Vector3(-0.15, 0.25, -0.1); earL.material = this.furMat;
        var earR = earL.clone(); earR.parent = head; earR.position.x = 0.15;

        var tail = BABYLON.MeshBuilder.CreateCylinder("tail", { diameterTop: 0.1, diameterBottom: 0.2, height: 0.8 }, scene);
        tail.parent = body; tail.rotation.x = Math.PI / 4; tail.position = new BABYLON.Vector3(0, 0.1, -0.6); tail.material = this.furMat;

        var createLeg = (name, dx, dz) => {
            var leg = BABYLON.MeshBuilder.CreateBox(name, { width: 0.15, height: 0.6, depth: 0.15 }, scene);
            leg.parent = body; leg.position = new BABYLON.Vector3(dx, -0.3, dz); leg.material = this.furMat;
            leg.setPivotPoint(new BABYLON.Vector3(0, 0.3, 0));
            return leg;
        };

        var legs = [
            createLeg("LegFL", -0.2, 0.5), createLeg("LegFR", 0.2, 0.5),
            createLeg("LegBL", -0.2, -0.5), createLeg("LegBR", 0.2, -0.5)
        ];

        this.coyotes.push({
            root: root,
            head: head,
            legs: legs,
            dir: new BABYLON.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize(),
            speed: 2.0,
            animTime: Math.random() * 100,
            stateTimer: 0,
            hp: 25,
            isFeral: false,
            visualTimer: 0
        });
    },

    createCoyotes: function (scene, count, core) {
        for (var i = 0; i < count; i++) {
            this.spawnCoyote(scene, core);
        }
    },

    // --- SURVIVORS ---
    createSurvivor: function (scene, x, z, isBandit) {
        var name = isBandit ? "bandit" : "npc";
        var npc = new BABYLON.TransformNode(name, scene);
        npc.position = new BABYLON.Vector3(x, 10, z);

        npc.data = {
            state: "walk",
            timer: 0.1,
            origin: new BABYLON.Vector3(x, 0, z),
            target: new BABYLON.Vector3(x + 5, 0, z + 5),
            animTime: Math.random() * 100,
            isFeral: isBandit,
            visualTimer: 0
        };
        npc.hp = 25;
        npc.root = npc; // Self-reference for combat system compatibility

        var skinMat = new BABYLON.StandardMaterial("skin", scene);
        skinMat.diffuseColor = new BABYLON.Color3(0.8, 0.6, 0.5);
        var clothMat = new BABYLON.StandardMaterial("cloth", scene);
        clothMat.diffuseColor = isBandit ? new BABYLON.Color3(0.6, 0.1, 0.1) : new BABYLON.Color3(0.3, 0.5, 0.8);

        var torso = BABYLON.MeshBuilder.CreateBox("torso", { width: 0.5, height: 0.7, depth: 0.3 }, scene);
        torso.parent = npc; torso.position.y = 1.1; torso.material = clothMat;
        var head = BABYLON.MeshBuilder.CreateSphere("head", { diameter: 0.35 }, scene);
        head.parent = torso; head.position.y = 0.5; head.material = skinMat;

        var createLimb = (w, h, px, py, pz) => {
            var limb = BABYLON.MeshBuilder.CreateBox("limb", { width: w, height: h, depth: w }, scene);
            var pivot = new BABYLON.TransformNode("piv", scene);
            pivot.parent = npc; pivot.position = new BABYLON.Vector3(px, py, pz);
            limb.parent = pivot; limb.position.y = -h / 2; limb.material = clothMat;
            return pivot;
        };

        npc.limbs = {
            la: createLimb(0.15, 0.6, -0.35, 1.4, 0),
            ra: createLimb(0.15, 0.6, 0.35, 1.4, 0),
            ll: createLimb(0.2, 0.75, -0.15, 0.75, 0),
            rl: createLimb(0.2, 0.75, 0.15, 0.75, 0)
        };

        var bag = BABYLON.MeshBuilder.CreateBox("bag", { width: 0.4, height: 0.5, depth: 0.2 }, scene);
        bag.parent = torso; bag.position.z = -0.25;
        var bagMat = new BABYLON.StandardMaterial("bagMat", scene);
        bagMat.diffuseColor = new BABYLON.Color3(0.3, 0.4, 0.2); bag.material = bagMat;

        this.survivors.push(npc);
        return npc;
    },

    spawnShopkeeper: function (scene, x, z, core) {
        var npc = new BABYLON.TransformNode("shopkeeper", scene);
        npc.position = new BABYLON.Vector3(x, 0, z);

        var skinMat = new BABYLON.StandardMaterial("shopSkin", scene);
        skinMat.diffuseColor = new BABYLON.Color3(0.7, 0.5, 0.4);
        var clothMat = new BABYLON.StandardMaterial("shopCloth", scene);
        clothMat.diffuseColor = new BABYLON.Color3(0.8, 0.8, 0.2); // Yellow/Gold merchant

        var torso = BABYLON.MeshBuilder.CreateBox("torso", { width: 0.6, height: 0.8, depth: 0.4 }, scene);
        torso.parent = npc; torso.position.y = 1.2; torso.material = clothMat;
        var head = BABYLON.MeshBuilder.CreateSphere("head", { diameter: 0.4 }, scene);
        head.parent = torso; head.position.y = 0.6; head.material = skinMat;

        // Hat
        var hat = BABYLON.MeshBuilder.CreateCylinder("hat", { diameterTop: 0.1, diameterBottom: 0.6, height: 0.4 }, scene);
        hat.parent = head; hat.position.y = 0.2; hat.material = clothMat;

        var createLimb = (w, h, px, py, pz) => {
            var limb = BABYLON.MeshBuilder.CreateBox("limb", { width: w, height: h, depth: w }, scene);
            limb.parent = npc; limb.position = new BABYLON.Vector3(px, py, pz);
            limb.material = clothMat;
        };

        createLimb(0.2, 0.8, -0.4, 1.4, 0); // la
        createLimb(0.2, 0.8, 0.4, 1.4, 0);  // ra
        createLimb(0.25, 1.0, -0.2, 0.5, 0); // ll
        createLimb(0.25, 1.0, 0.2, 0.5, 0);  // rl

        // Shop Stand/Table
        var table = BABYLON.MeshBuilder.CreateBox("table", { width: 2.5, height: 1.0, depth: 1.2 }, scene);
        table.parent = npc; table.position = new BABYLON.Vector3(0, 0.5, 1.0);
        var tableMat = new BABYLON.StandardMaterial("tableMat", scene);
        tableMat.diffuseColor = new BABYLON.Color3(0.4, 0.3, 0.2);
        table.material = tableMat;

        this.shopkeepers.push(npc);
        core.createBlip(npc, "Gold", "shop");
    },

    spawnFriendlyNPC: function (scene, core) {
        this.spawnTrader(scene, core);
        this.spawnMechanic(scene, core);
    },

    spawnTrader: function (scene, core) {
        var x = 50, z = 50;
        var gH = core.getHeightAt(x, z);

        var npc = new BABYLON.TransformNode("trader_character", scene);
        npc.position = new BABYLON.Vector3(x, gH, z);

        var clothMat = new BABYLON.StandardMaterial("traderCloth", scene);
        clothMat.diffuseColor = new BABYLON.Color3(0.2, 0.6, 0.2);
        var skinMat = new BABYLON.StandardMaterial("traderSkin", scene);
        skinMat.diffuseColor = new BABYLON.Color3(0.8, 0.6, 0.4);

        var torso = BABYLON.MeshBuilder.CreateBox("torso", { width: 0.6, height: 0.8, depth: 0.4 }, scene);
        torso.parent = npc; torso.position.y = 1.2; torso.material = clothMat;
        var head = BABYLON.MeshBuilder.CreateSphere("head", { diameter: 0.4 }, scene);
        head.parent = torso; head.position.y = 0.6; head.material = skinMat;

        var hat = BABYLON.MeshBuilder.CreateCylinder("hat", { diameterTop: 0.8, diameterBottom: 0.8, height: 0.1 }, scene);
        hat.parent = head; hat.position.y = 0.2; hat.material = clothMat;

        var shopRoot = new BABYLON.TransformNode("tradingPost", scene);
        shopRoot.position = new BABYLON.Vector3(x, gH, z + 1.5);

        var scrapMat = new BABYLON.StandardMaterial("shopScrapMat", scene);
        scrapMat.diffuseColor = new BABYLON.Color3(0.3, 0.25, 0.2);
        var stallMat = new BABYLON.StandardMaterial("stallMat", scene);
        stallMat.diffuseColor = new BABYLON.Color3(0.4, 0.3, 0.2);

        var p1 = BABYLON.MeshBuilder.CreateBox("p1", { width: 0.2, height: 4, depth: 0.2 }, scene);
        p1.parent = shopRoot; p1.position = new BABYLON.Vector3(-2, 2, -1.5); p1.material = scrapMat;
        var p2 = p1.clone("p2"); p2.position.x = 2;
        var p3 = p1.clone("p3"); p3.position.z = 1.5; p3.position.y = 1.6; p3.scaling.y = 0.8;
        var p4 = p3.clone("p4"); p4.position.x = -2;

        var counter = BABYLON.MeshBuilder.CreateBox("counter", { width: 4.2, height: 1.1, depth: 1.0 }, scene);
        counter.parent = shopRoot; counter.position = new BABYLON.Vector3(0, 0.55, -1.2);
        counter.material = stallMat;

        var roof = BABYLON.MeshBuilder.CreateBox("roof", { width: 4.6, height: 0.1, depth: 3.5 }, scene);
        roof.parent = shopRoot; roof.position = new BABYLON.Vector3(0, 3.8, 0); roof.rotation.x = -0.15; roof.material = scrapMat;

        var wallL = BABYLON.MeshBuilder.CreateBox("wallL", { width: 0.1, height: 3, depth: 3 }, scene);
        wallL.parent = shopRoot; wallL.position = new BABYLON.Vector3(-2.1, 1.5, 0.2); wallL.material = scrapMat;
        var wallR = wallL.clone("wallR"); wallR.position.x = 2.1;
        var wallB = BABYLON.MeshBuilder.CreateBox("wallB", { width: 4.2, height: 2, depth: 0.1 }, scene);
        wallB.parent = shopRoot; wallB.position = new BABYLON.Vector3(0, 1, 1.6); wallB.material = scrapMat;

        npc.data = { type: "SHOP", name: "Trader" };
        this.shopkeepers.push(npc);
        core.createBlip(npc, "Lime", "shop");
    },

    spawnMechanic: function (scene, core) {
        var x = -50, z = -50;
        var gH = core.getHeightAt(x, z);

        var npc = new BABYLON.TransformNode("mechanic_character", scene);
        npc.position = new BABYLON.Vector3(x, gH, z);

        var clothMat = new BABYLON.StandardMaterial("mechCloth", scene);
        clothMat.diffuseColor = new BABYLON.Color3(0.3, 0.3, 0.3);
        var skinMat = new BABYLON.StandardMaterial("mechSkin", scene);
        skinMat.diffuseColor = new BABYLON.Color3(0.7, 0.5, 0.3);

        var torso = BABYLON.MeshBuilder.CreateBox("torso", { width: 0.7, height: 0.9, depth: 0.4 }, scene);
        torso.parent = npc; torso.position.y = 1.2; torso.material = clothMat;
        var head = BABYLON.MeshBuilder.CreateSphere("head", { diameter: 0.45 }, scene);
        head.parent = torso; head.position.y = 0.6; head.material = skinMat;

        var mask = BABYLON.MeshBuilder.CreateBox("mask", { width: 0.3, height: 0.4, depth: 0.1 }, scene);
        mask.parent = head; mask.position = new BABYLON.Vector3(0, 0, 0.2);
        var maskMat = new BABYLON.StandardMaterial("maskMat", scene);
        maskMat.diffuseColor = BABYLON.Color3.Black(); mask.material = maskMat;

        var garageRoot = new BABYLON.TransformNode("garageStruct", scene);
        garageRoot.position = new BABYLON.Vector3(x, gH, z + 4.0); garageRoot.rotation.y = Math.PI;

        var darkMetal = new BABYLON.StandardMaterial("garageMetal", scene);
        darkMetal.diffuseColor = new BABYLON.Color3(0.15, 0.15, 0.15);
        var benchMat = new BABYLON.StandardMaterial("benchMat", scene);
        benchMat.diffuseColor = new BABYLON.Color3(0.2, 0.2, 0.25);

        var gp1 = BABYLON.MeshBuilder.CreateBox("gp1", { width: 0.4, height: 6, depth: 0.4 }, scene);
        gp1.parent = garageRoot; gp1.position = new BABYLON.Vector3(-4, 3, -3); gp1.material = darkMetal;
        var gp2 = gp1.clone("gp2"); gp2.position.x = 4;
        var gp3 = gp1.clone("gp3"); gp3.position.z = 3;
        var gp4 = gp2.clone("gp4"); gp4.position.z = 3;

        var gRoof = BABYLON.MeshBuilder.CreateBox("gRoof", { width: 9, height: 0.2, depth: 7 }, scene);
        gRoof.parent = garageRoot; gRoof.position.y = 6; gRoof.material = darkMetal;

        var lift1 = BABYLON.MeshBuilder.CreateCylinder("l1", { diameter: 0.3, height: 4 }, scene);
        lift1.parent = garageRoot; lift1.position = new BABYLON.Vector3(-2.5, 2, 0); lift1.material = benchMat;
        var lift2 = lift1.clone("l2"); lift2.position.x = 2.5;

        var arm = BABYLON.MeshBuilder.CreateBox("arm", { width: 6, height: 0.2, depth: 0.5 }, scene);
        arm.parent = garageRoot; arm.position.y = 1.5; arm.material = benchMat;

        var bench = BABYLON.MeshBuilder.CreateBox("workbench", { width: 2.5, height: 1, depth: 1.2 }, scene);
        bench.parent = garageRoot; bench.position = new BABYLON.Vector3(-3, 0.5, -2); bench.material = benchMat;

        npc.data = { type: "GARAGE", name: "Mechanic" };
        this.shopkeepers.push(npc);
        core.createBlip(npc, "Orange", "mechanic");
    },

    spawnSpider: function (scene, x, z, core) {
        BABYLON.SceneLoader.ImportMeshAsync("", "./", "Wasteland_Widow.glb", scene).then((result) => {
            var root = result.meshes[0];
            var y = core.getHeightAt(x, z);
            root.position = new BABYLON.Vector3(x, y + 2.5, z);

            var legs = [];
            var allNodes = result.transformNodes.concat(result.meshes);
            allNodes.forEach(n => {
                if (n.name.includes("Leg")) {
                    if (n.rotationQuaternion) {
                        n.rotation = n.rotationQuaternion.toEulerAngles();
                        n.rotationQuaternion = null;
                    }
                    n.metadata = { baseRot: n.rotation.clone(), phase: Math.random() * Math.PI * 2 };
                    legs.push(n);
                }
            });

            this.spiders.push({
                root: root, legs: legs, t: Math.random() * 100,
                speed: 4.0, dir: new BABYLON.Vector3(0, 0, 1),
                targetIndex: Math.floor(Math.random() * 5)
            });
        });
    },

    spawnHelicopter: function (scene, x, z, core) {
        BABYLON.SceneLoader.ImportMeshAsync("", "./", "WastelandHellCopter.glb", scene).then((result) => {
            var root = result.meshes[0];
            root.scaling = new BABYLON.Vector3(3.3, 3.3, 3.3);
            var y = core.getHeightAt(x, z);
            root.position = new BABYLON.Vector3(x, y + 6.0, z);

            var mainRotor = null, tailRotor = null;
            result.transformNodes.concat(result.meshes).forEach(n => {
                if (n.rotationQuaternion) { n.rotation = n.rotationQuaternion.toEulerAngles(); n.rotationQuaternion = null; }
                if (n.name.includes("RotorHub")) mainRotor = n;
                if (n.name.includes("TailRotorShaft")) tailRotor = n;
            });

            this.helis.push({ root: root, mainRotor: mainRotor, tailRotor: tailRotor, speed: 15.0, dir: new BABYLON.Vector3(0, 0, 1), targetIndex: 0 });
        });
    },

    spawnNuclearHydra: function (scene, x, z, core) {
        BABYLON.SceneLoader.ImportMeshAsync("", "./", "NuclearHydra.glb", scene).then((result) => {
            var root = result.meshes[0];
            var groundY = core.getHeightAt(x, z);
            root.position = new BABYLON.Vector3(x, groundY + 10, z);
            root.scaling = new BABYLON.Vector3(1.5, 1.5, 1.5);

            var parts = {};
            result.transformNodes.concat(result.meshes).forEach(n => {
                if (n.rotationQuaternion) { n.rotation = n.rotationQuaternion.toEulerAngles(); n.rotationQuaternion = null; }
                if (n.name.includes("wing_l_1")) parts.wingL1 = n;
                if (n.name.includes("wing_l_2")) parts.wingL2 = n;
                if (n.name.includes("wing_r_1")) parts.wingR1 = n;
                if (n.name.includes("wing_r_2")) parts.wingR2 = n;
                if (n.name.includes("neck_c")) parts.neckC = n;
                if (n.name.includes("neck_l")) parts.neckL = n;
                if (n.name.includes("neck_r")) parts.neckR = n;
                if (n.name.includes("head_c")) parts.headC = n;
                if (n.name.includes("head_l")) parts.headL = n;
                if (n.name.includes("head_r")) parts.headR = n;
            });

            this.hydras.push({
                root: root, parts: parts, t: 0, hp: 500, speed: 8.0,
                dir: new BABYLON.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize()
            });

            core.createBlip(root, "Magenta", "boss");
            console.log("THE NUCLEAR HYDRA HAS AWAKENED!");
        });
    },

    createBossTanker: function (scene, x, z, core) {
        var cab = new BABYLON.MeshBuilder.CreateBox("bossCab", { width: 3.5, height: 4, depth: 5 }, scene);
        cab.position = new BABYLON.Vector3(x, 10, z);
        var cabMat = new BABYLON.StandardMaterial("cabMat", scene);
        cabMat.diffuseColor = new BABYLON.Color3(0.4, 0.1, 0.1); cab.material = cabMat;

        var wheelMat = new BABYLON.StandardMaterial("bossWheel", scene);
        wheelMat.diffuseColor = new BABYLON.Color3(0.05, 0.05, 0.05);

        var addWheel = (parent, wx, wz) => {
            var w = BABYLON.MeshBuilder.CreateCylinder("bw", { diameter: 2.5, height: 1.2 }, scene);
            w.rotation.z = Math.PI / 2; w.parent = parent; w.position = new BABYLON.Vector3(wx, -1, wz); w.material = wheelMat;
        };
        addWheel(cab, 2, 1.5); addWheel(cab, -2, 1.5); addWheel(cab, 2, -1.5); addWheel(cab, -2, -1.5);

        var trailer = BABYLON.MeshBuilder.CreateCylinder("trailer", { diameter: 3.5, height: 12 }, scene);
        trailer.rotation.x = Math.PI / 2; trailer.material = new BABYLON.StandardMaterial("tankMat", scene);
        trailer.material.diffuseColor = new BABYLON.Color3(0.7, 0.7, 0.75);

        var tChassis = new BABYLON.TransformNode("tChassis", scene);
        tChassis.parent = trailer; tChassis.rotation.x = -Math.PI / 2;
        addWheel(tChassis, 2, -4); addWheel(tChassis, -2, -4);

        trailer.position = new BABYLON.Vector3(x, 10, z - 8);
        this.bosses.push({ cab: cab, trailer: trailer, dir: new BABYLON.Vector3(0, 0, 1), speed: 5.0, hp: 50, targetIndex: 0 });
        core.createBlip(cab, "Orange", "enemy");
    },

    update: function (dt, core) {
        this.updateFauna(dt, core);
        this.updateSurvivors(dt, core);
        this.updateSpiders(dt, core);
        this.updateHelis(dt, core);
        this.updateBosses(dt, core);
        this.updateHydras(dt, core);
        this.updateShopkeepers(dt, core);
    },

    updateShopkeepers: function (dt, core) {
        this.shopkeepers.forEach(s => {
            var gH = core.getHeightFast(s.position.x, s.position.z);
            s.position.y = gH;
            var dist = BABYLON.Vector3.Distance(s.position, core.vehicle.position);
            if (dist < 15) {
                var dir = core.vehicle.position.subtract(s.position);
                dir.y = 0; s.rotation.y = Math.atan2(dir.x, dir.z);
            }
        });
    },

    updateFauna: function (dt, core) {
        this.snakes.forEach(s => {
            var head = s.segments[0];
            if (s.isFeral && WastelandHero.mesh) {
                var targetDir = WastelandHero.mesh.position.subtract(head.position);
                targetDir.y = 0; var dist = targetDir.length(); targetDir.normalize();
                if (dist > 1.5) {
                    s.dir = BABYLON.Vector3.Lerp(s.dir, targetDir, 5.0 * dt).normalize();
                    head.position.addInPlace(s.dir.scale(s.speed * dt));
                }
                if (s.visualTimer > 0) {
                    s.visualTimer -= dt * 5; var b = Math.sin(s.visualTimer * Math.PI);
                    head.scaling.setAll(1.0 + b * 0.4);
                } else head.scaling.setAll(1.0);
            } else {
                s.turnTimer -= dt;
                if (s.turnTimer <= 0) {
                    s.dir = new BABYLON.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize();
                    s.turnTimer = 2.0 + Math.random() * 3.0;
                }
                head.position.addInPlace(s.dir.scale(s.speed * dt));
            }
            head.position.y = core.getHeightFast(head.position.x, head.position.z) + 0.2;
            head.rotation.y = Math.atan2(s.dir.x, s.dir.z);

            for (var i = 1; i < s.segments.length; i++) {
                var curr = s.segments[i], prev = s.segments[i - 1];
                var diff = prev.position.subtract(curr.position);
                var minDist = 0.45;
                if (diff.length() > minDist) {
                    var target = prev.position.subtract(diff.normalize().scale(minDist));
                    curr.position = BABYLON.Vector3.Lerp(curr.position, target, 15 * dt);
                    curr.position.y = core.getHeightFast(curr.position.x, curr.position.z) + 0.2;
                }
                if (diff.length() > 0.01) curr.rotation.y = Math.atan2(diff.x, diff.z);
            }
        });

        this.coyotes.forEach(c => {
            if (c.isFeral && WastelandHero.mesh) {
                var targetDir = WastelandHero.mesh.position.subtract(c.root.position);
                targetDir.y = 0; var dist = targetDir.length(); targetDir.normalize();
                if (dist > 2.5) {
                    c.dir = BABYLON.Vector3.Lerp(c.dir, targetDir, 5.0 * dt).normalize();
                    c.root.position.addInPlace(c.dir.scale(4.0 * dt));
                }
            } else {
                c.stateTimer -= dt;
                if (c.stateTimer <= 0) {
                    c.dir = new BABYLON.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize();
                    c.stateTimer = 4.0 + Math.random() * 4.0;
                }
                c.root.position.addInPlace(c.dir.scale(4.0 * dt));
            }

            c.root.position.y = core.getHeightFast(c.root.position.x, c.root.position.z) + 0.5;
            var angle = Math.atan2(c.dir.x, c.dir.z);
            c.root.rotation.y = BABYLON.Scalar.Lerp(c.root.rotation.y, angle, 5.0 * dt);

            if (c.visualTimer > 0) {
                c.visualTimer -= dt * 5; var b = Math.sin(c.visualTimer * Math.PI);
                c.head.position.z = 0.6 + (b * 0.4); c.head.scaling.setAll(1.0 + (b * 0.2));
            } else { c.head.position.z = 0.6; c.head.scaling.setAll(1.0); }

            c.animTime += dt * 10.0;
            var amp = 0.5;
            c.legs[0].rotation.x = Math.sin(c.animTime) * amp; c.legs[3].rotation.x = Math.sin(c.animTime) * amp;
            c.legs[1].rotation.x = Math.cos(c.animTime) * amp; c.legs[2].rotation.x = Math.cos(c.animTime) * amp;
        });
    },

    updateSurvivors: function (dt, core) {
        var gravity = 9.8;
        this.survivors.forEach(s => {
            if (s.isDisposed()) return;
            var gH = core.getHeightFast(s.position.x, s.position.z);
            var floor = gH + 1.0;
            if (s.position.y > floor + 0.05) s.position.y -= gravity * dt;
            else s.position.y = floor;

            s.data.timer -= dt;
            if (s.data.timer <= 0) {
                if (s.data.state === "idle") {
                    s.data.state = "walk"; s.data.timer = 5 + Math.random() * 5;
                    var angle = Math.random() * Math.PI * 2;
                    s.data.target.x = s.data.origin.x + Math.sin(angle) * 8;
                    s.data.target.z = s.data.origin.z + Math.cos(angle) * 8;
                } else { s.data.state = "idle"; s.data.timer = 2 + Math.random() * 2; }
            }

            var isChasing = false;
            // BANDIT AI OPTIMIZATION: Ignore player in car, proximity check
            if (s.data.isFeral && WastelandHero.mesh && !core.isDriving) {
                var targetDir = WastelandHero.mesh.position.subtract(s.position);
                targetDir.y = 0;
                var dist = targetDir.length();

                if (dist < 60) {
                    isChasing = true;
                    targetDir.normalize();

                    if (dist > 2.5) {
                        s.position.addInPlace(targetDir.scale(4 * dt));
                        var desiredAngle = Math.atan2(targetDir.x, targetDir.z);
                        s.rotation.y = BABYLON.Scalar.Lerp(s.rotation.y, desiredAngle, 10 * dt);

                        s.data.animTime += dt * 10;
                        var sin = Math.sin(s.data.animTime);
                        s.limbs.la.rotation.x = sin * 0.5; s.limbs.ra.rotation.x = -sin * 0.5;
                        s.limbs.ll.rotation.x = -sin * 0.5; s.limbs.rl.rotation.x = sin * 0.5;
                    } else {
                        var angle = Math.atan2(targetDir.x, targetDir.z);
                        s.rotation.y = BABYLON.Scalar.Lerp(s.rotation.y, angle, 10 * dt);

                        if (s.data.visualTimer > 0) {
                            s.data.visualTimer -= dt * 5;
                            var swing = Math.sin(s.data.visualTimer * Math.PI);
                            s.limbs.ra.rotation.x = -1.5 * swing;
                            s.limbs.la.rotation.x = 0.5 * swing;
                        } else {
                            s.limbs.la.rotation.x *= 0.9; s.limbs.ra.rotation.x *= 0.9;
                            s.limbs.ll.rotation.x *= 0.9; s.limbs.rl.rotation.x *= 0.9;
                        }
                    }
                }
            }

            if (!isChasing && s.data.state === "walk") {
                var dx = s.data.target.x - s.position.x, dz = s.data.target.z - s.position.z;
                var dist = Math.sqrt(dx * dx + dz * dz);
                if (dist < 0.5) s.data.state = "idle";
                else {
                    s.position.x += (dx / dist) * 3 * dt;
                    s.position.z += (dz / dist) * 3 * dt;
                    var desiredAngle = Math.atan2(dx, dz);
                    var diff = desiredAngle - s.rotation.y;
                    while (diff > Math.PI) diff -= Math.PI * 2;
                    while (diff < -Math.PI) diff += Math.PI * 2;
                    s.rotation.y += diff * 5 * dt;

                    s.data.animTime += dt * 10;
                    var sin = Math.sin(s.data.animTime);
                    s.limbs.la.rotation.x = sin * 0.5; s.limbs.ra.rotation.x = -sin * 0.5;
                    s.limbs.ll.rotation.x = -sin * 0.5; s.limbs.rl.rotation.x = sin * 0.5;
                }
            } else if (!isChasing) {
                Object.values(s.limbs).forEach(l => l.rotation.x *= 0.9);
            }
        });
    },

    updateSpiders: function (dt, core) {
        this.spiders.forEach(s => {
            s.t += dt * 15.0;
            s.root.position.addInPlace(s.dir.scale(s.speed * dt));
            s.root.rotation.y = Math.atan2(s.dir.x, s.dir.z);
            var gH = core.getHeightFast(s.root.position.x, s.root.position.z);
            s.root.position.y = BABYLON.Scalar.Lerp(s.root.position.y, gH + 2.5, 10 * dt);

            s.legs.forEach(l => {
                var offset = Math.sin(s.t + l.metadata.phase) * 0.8;
                l.rotation.x = l.metadata.baseRot.x + offset * 0.5;
            });
        });
    },

    updateHelis: function (dt, core) {
        this.helis.forEach(h => {
            h.root.position.addInPlace(h.dir.scale(h.speed * dt));
            var gH = core.getHeightFast(h.root.position.x, h.root.position.z);
            h.root.position.y = BABYLON.Scalar.Lerp(h.root.position.y, gH + 6.0, 2.0 * dt);
            h.root.rotation.y = Math.atan2(h.dir.x, h.dir.z);
            h.root.rotation.x = 0.2;
            if (h.mainRotor) h.mainRotor.rotation.y += 300 * dt;
            if (h.tailRotor) h.tailRotor.rotation.x += 300 * dt;
        });
    },

    updateBosses: function (dt, core) {
        this.bosses.forEach(b => {
            b.cab.position.addInPlace(b.dir.scale(b.speed * dt));
            b.cab.position.y = core.getHeightFast(b.cab.position.x, b.cab.position.z) + 2.0;
            var targetAngle = Math.atan2(b.dir.x, b.dir.z);
            var diff = targetAngle - b.cab.rotation.y;
            while (diff < -Math.PI) diff += Math.PI * 2;
            while (diff > Math.PI) diff -= Math.PI * 2;
            b.cab.rotation.y += diff * 1.0 * dt;

            var hitch = b.cab.position.add(new BABYLON.Vector3(Math.sin(b.cab.rotation.y), 0, Math.cos(b.cab.rotation.y)).scale(-5));
            var diffT = hitch.subtract(b.trailer.position);
            if (diffT.length() > 0.5) {
                b.trailer.position = BABYLON.Vector3.Lerp(b.trailer.position, hitch.subtract(diffT.normalize().scale(0.5)), 5 * dt);
                b.trailer.position.y = core.getHeightFast(b.trailer.position.x, b.trailer.position.z) + 2.0;
                b.trailer.rotation.y = Math.atan2(diffT.x, diffT.z);
            }
        });
    },

    updateHydras: function (dt, core) {
        this.hydras.forEach(h => {
            h.t += dt;
            var dist = BABYLON.Vector3.Distance(h.root.position, core.vehicle.position);
            var targetDir = core.vehicle.position.subtract(h.root.position).normalize();
            targetDir.y = 0;
            if (dist > 50) h.dir = BABYLON.Vector3.Lerp(h.dir, targetDir, 0.5 * dt).normalize();
            else {
                var right = BABYLON.Vector3.Cross(targetDir, BABYLON.Vector3.Up());
                h.dir = BABYLON.Vector3.Lerp(h.dir, right, 0.5 * dt).normalize();
            }
            h.root.position.addInPlace(h.dir.scale(h.speed * dt));
            var gH = core.getHeightFast(h.root.position.x, h.root.position.z);
            var targetH = gH + 15 + Math.sin(h.t * 0.5) * 5;
            h.root.position.y = BABYLON.Scalar.Lerp(h.root.position.y, targetH, dt);
            h.root.rotation.y = Math.atan2(h.dir.x, h.dir.z);

            var flap = Math.sin(h.t * 3.0);
            if (h.parts.wingL1) h.parts.wingL1.rotation.z = 0.3 + flap * 0.4;
            if (h.parts.wingL2) h.parts.wingL2.rotation.z = flap * 0.5;
            if (h.parts.wingR1) h.parts.wingR1.rotation.z = -0.3 - flap * 0.4;
            if (h.parts.wingR2) h.parts.wingR2.rotation.z = -flap * 0.5;

            var weave = Math.sin(h.t * 1.5);
            if (h.parts.neckC) { h.parts.neckC.rotation.y = weave * 0.2; h.parts.neckC.rotation.x = 0.4 + weave * 0.1; }
            if (h.parts.neckL) { h.parts.neckL.rotation.y = -0.5 + weave * 0.3; h.parts.neckL.rotation.x = weave * 0.2; }
            if (h.parts.neckR) { h.parts.neckR.rotation.y = 0.5 + weave * 0.3; h.parts.neckR.rotation.x = -weave * 0.2; }

            var lookAtPlayer = (head) => {
                if (!head) return;
                head.lookAt(core.vehicle.position);
            };
            lookAtPlayer(h.parts.headC); lookAtPlayer(h.parts.headL); lookAtPlayer(h.parts.headR);
        });
    }
};
